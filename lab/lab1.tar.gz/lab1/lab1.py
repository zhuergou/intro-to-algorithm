import timeit
import pylab as pl
import math

def fib1(n):
    if n == 1:
        return 1
    if n == 0:
        return 0
    else:
        #print "Computing", n
        return fib1(n-1) + fib1(n-2)

def fib2(n):
    if n == 1:
        return 1
    if n == 0:
        return 0
    else:
        sofar = [0,1]
        for i in range(2,n+1):
            sofar.append(sofar[i-2]+sofar[i-1])
        return sofar[n]

def fib3(n):
    a = ((1+math.sqrt(5))/2)**n
    b = ((1-math.sqrt(5))/2)**n
    return (a-b)/math.sqrt(5)

def exp1():
    fib1array = []
    fib2array = []
    rep = 10**6
    Nvals = [1, 5, 10, 15, 20, 25, 30, 35, 40, 41, 42, 43]
    for i in Nvals:
        starttime = timeit.default_timer()
        k = fib1(i)
        endtime = timeit.default_timer()
        print("n=",i,"outcome=",k, ", time=", endtime-starttime)
        fib1array.append(endtime-starttime)

        starttime = timeit.default_timer()
        for r in range(rep):
            k = fib2(i)
        endtime = timeit.default_timer()
        avgtime = (endtime-starttime)/rep
        fib2array.append(avgtime)

        # starttime = timeit.default_timer()
        # for r in range(rep):
        #     k = fib3(i)
        # endtime = timeit.default_timer()
        # avgtime = (endtime-starttime)/rep
        # print("n=",i,"outcome=",k, ", time=", avgtime)
    pl.plot(Nvals, fib2array, 'bs', Nvals, fib1array, 'r--')
    pl.savefig('fig1.png')

def exp2():
    fib2array = []
    Nvals = [2**10, 2**12, 2**14, 2**16, 2**18, 2**19]
    for i in Nvals:
        starttime = timeit.default_timer()
        k = fib2(i)
        endtime = timeit.default_timer()
        ttime = endtime-starttime
        print("n=",i, "Fn = ", k, " time=", ttime)
        fib2array.append(ttime)
        # starttime = timeit.default_timer()
        # k = fib3(i)
        # endtime = timeit.default_timer()
        # ttime = endtime-starttime
        # print("n=",i, " time=", ttime)

    pl.plot(Nvals, fib2array, 'r--')
    pl.savefig('fig2.png')


exp1()
exp2()
